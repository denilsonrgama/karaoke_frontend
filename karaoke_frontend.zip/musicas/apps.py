from django.apps import AppConfig


class MusicasConfig(AppConfig):
    name = 'musicas'
