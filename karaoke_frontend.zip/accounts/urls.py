#accounts/urls.py
from django import views
from django.urls import path
from .views import dashboard, register_view, logout_view


urlpatterns = [    
    path("register/", register_view, name="register"),
    path("dashboard/", dashboard, name="dashboard"),
    path("logout/", logout_view, name="logout"),
]   